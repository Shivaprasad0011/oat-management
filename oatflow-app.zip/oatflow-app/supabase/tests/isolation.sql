-- OatFlow account-isolation and access tests.
--
-- Run the whole file as one statement (Supabase SQL editor, psql, or an SQL tool) AFTER 0001_init.sql.
-- It creates two throwaway users (Alice and Bob), then acts as each of them, and as a signed-out visitor,
-- by switching the database role and JWT claims the same way Supabase does for API requests.
--
-- The file always ends with an intentional error whose message is the test report. That error rolls the
-- whole transaction back, so no test users or rows are ever saved.
-- Read the report: every line starts with PASS or FAIL.

do $test$
declare
  alice constant text := '00000000-0000-0000-0000-00000000000a';
  bob   constant text := '00000000-0000-0000-0000-00000000000b';
  t        record;
  v_ok     boolean;
  v_text   text;
  v_rows   integer;
  v_state  text;
  v_pass   integer := 0;
  v_total  integer := 0;
  v_report text := '';
begin
  for t in
    select * from (values
      (1,  'setup: create two users', 'postgres',
        $q$insert into auth.users (id, email) values
           ('00000000-0000-0000-0000-00000000000a', 'alice@test.local'),
           ('00000000-0000-0000-0000-00000000000b', 'bob@test.local')$q$, 'ok'),

      (2,  'alice adds a product', 'alice',
        $q$insert into public.products (name, package_size, price, stock, status)
           values ('Alice Oats', '1 kg', 100, 10, 'active')$q$, 'rows:1'),
      (3,  'bob adds a product', 'bob',
        $q$insert into public.products (name, package_size, price, stock, status)
           values ('Bob Oats', '500 g', 50, 5, 'active')$q$, 'rows:1'),
      (4,  'setup: remember product ids', 'postgres',
        $q$select set_config('t.alice_product', (select id::text from public.products where name = 'Alice Oats'), true),
                  set_config('t.bob_product',   (select id::text from public.products where name = 'Bob Oats'), true)$q$, 'ok'),

      (5,  'alice sees exactly one product', 'alice', $q$select count(*) from public.products$q$, 'value:1'),
      (6,  'bob sees only his own product', 'bob', $q$select name from public.products$q$, 'value:Bob Oats'),
      (7,  'bob cannot read alice''s product by id', 'bob',
        $q$select count(*) from public.products where id = current_setting('t.alice_product')::uuid$q$, 'value:0'),
      (8,  'bob cannot update alice''s product', 'bob',
        $q$update public.products set price = 1 where id = current_setting('t.alice_product')::uuid$q$, 'rows:0'),
      (9,  'bob cannot delete alice''s product', 'bob',
        $q$delete from public.products where id = current_setting('t.alice_product')::uuid$q$, 'rows:0'),
      (10, 'bob cannot insert a product owned by alice', 'bob',
        $q$insert into public.products (user_id, name, package_size, price, stock)
           values ('00000000-0000-0000-0000-00000000000a', 'Planted', '1 kg', 10, 1)$q$, 'error:42501'),
      (11, 'alice cannot hand her product to bob', 'alice',
        $q$update public.products set user_id = '00000000-0000-0000-0000-00000000000b' where name = 'Alice Oats'$q$, 'error:42501'),

      (12, 'alice creates an order', 'alice',
        $q$select public.create_order(current_setting('t.alice_product')::uuid, 'Test Customer', 2)$q$, 'ok'),
      (13, 'creating the order lowered stock to 8', 'alice',
        $q$select stock::text from public.products where name = 'Alice Oats'$q$, 'value:8'),
      (14, 'first order number is 1001', 'alice', $q$select order_number::text from public.orders$q$, 'value:1001'),
      (15, 'order total is calculated by the database', 'alice', $q$select total_price::text from public.orders$q$, 'value:200.00'),
      (16, 'bob sees none of alice''s orders', 'bob', $q$select count(*) from public.orders$q$, 'value:0'),
      (17, 'bob cannot order alice''s product', 'bob',
        $q$select public.create_order(current_setting('t.alice_product')::uuid, 'Intruder', 1)$q$, 'error:P0002'),
      (18, 'bob cannot insert an order directly', 'bob',
        $q$insert into public.orders (order_number, product_name, package_size, unit_price, quantity, total_price, customer_name)
           values (1, 'x', '1 kg', 1, 1, 1, 'x')$q$, 'error:42501'),
      (19, 'bob cannot change the status of alice''s order', 'bob',
        $q$update public.orders set status = 'completed'$q$, 'rows:0'),
      (20, 'alice cannot edit an order price after creating it', 'alice',
        $q$update public.orders set unit_price = 1$q$, 'error:42501'),
      (21, 'cannot order more than the stock', 'alice',
        $q$select public.create_order(current_setting('t.alice_product')::uuid, 'Big Order', 999)$q$, 'error:23514'),
      (22, 'invalid order status is rejected', 'alice',
        $q$select public.create_order(current_setting('t.alice_product')::uuid, 'Odd Status', 1, 'shipped')$q$, 'error:22023'),

      (23, 'no sales records until an order is completed', 'alice', $q$select count(*) from public.sales_records$q$, 'value:0'),
      (24, 'alice completes her order', 'alice', $q$update public.orders set status = 'completed'$q$, 'rows:1'),
      (25, 'alice now has one sales record', 'alice', $q$select count(*) from public.sales_records$q$, 'value:1'),
      (26, 'bob sees none of alice''s sales records', 'bob', $q$select count(*) from public.sales_records$q$, 'value:0'),

      (27, 'signed-out visitor cannot read products', 'anon', $q$select count(*) from public.products$q$, 'error:42501'),
      (28, 'signed-out visitor cannot create orders', 'anon',
        $q$select public.create_order(current_setting('t.alice_product')::uuid, 'Ghost', 1)$q$, 'error:42501'),
      (29, 'signed-out visitor cannot read sales records', 'anon', $q$select count(*) from public.sales_records$q$, 'error:42501'),

      (30, 'product price must be above zero', 'alice',
        $q$insert into public.products (name, package_size, price, stock) values ('Free Oats', '1 kg', 0, 1)$q$, 'error:23514'),
      (31, 'product stock cannot be negative', 'alice',
        $q$update public.products set stock = -1 where name = 'Alice Oats'$q$, 'error:23514'),

      (32, 'alice deletes her product', 'alice', $q$delete from public.products where name = 'Alice Oats'$q$, 'rows:1'),
      (33, 'the order history survives the deletion', 'alice', $q$select count(*) from public.orders where product_id is null$q$, 'value:1')
    ) as x(n, name, actor, sql, expect)
    order by n
  loop
    v_total := v_total + 1;
    v_ok := false; v_text := null; v_state := null;

    execute 'reset role';
    perform set_config('request.jwt.claims', '', true);
    if t.actor = 'alice' then
      perform set_config('request.jwt.claims', json_build_object('sub', alice, 'role', 'authenticated')::text, true);
      execute 'set local role authenticated';
    elsif t.actor = 'bob' then
      perform set_config('request.jwt.claims', json_build_object('sub', bob, 'role', 'authenticated')::text, true);
      execute 'set local role authenticated';
    elsif t.actor = 'anon' then
      execute 'set local role anon';
    end if;

    begin
      if t.expect like 'value:%' then
        execute t.sql into v_text;
        v_ok := (v_text = substr(t.expect, 7));
      elsif t.expect like 'rows:%' then
        execute t.sql;
        get diagnostics v_rows = row_count;
        v_ok := (v_rows = substr(t.expect, 6)::integer);
        v_text := v_rows::text || ' rows';
      elsif t.expect = 'ok' then
        execute t.sql;
        v_ok := true;
      else
        execute t.sql;
        v_text := 'no error was raised';
      end if;
    exception when others then
      v_state := sqlstate;
      if t.expect like 'error:%' then
        v_ok := (v_state = substr(t.expect, 7));
      end if;
      v_text := 'error ' || v_state || ': ' || sqlerrm;
    end;

    if v_ok then v_pass := v_pass + 1; end if;
    v_report := v_report || format(E'\n%s %s. %s (expected %s%s)',
      case when v_ok then 'PASS' else 'FAIL' end, t.n, t.name, t.expect,
      case when v_ok then '' else '; got ' || coalesce(v_text, 'nothing') end);
  end loop;

  execute 'reset role';
  raise exception E'OATFLOW_TEST_REPORT: % of % checks passed (nothing was saved)%', v_pass, v_total, v_report;
end
$test$;
