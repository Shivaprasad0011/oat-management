-- OatFlow database schema.
-- Every row belongs to one user (user_id). Row-Level Security makes the database itself refuse
-- any read or write on rows owned by someone else, no matter what the client sends.
-- Requires PostgreSQL 15+ (Supabase default): column-level ON DELETE SET NULL and security_invoker views.

-- ---------------------------------------------------------------------------
-- Products
-- ---------------------------------------------------------------------------
create table public.products (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null default auth.uid() references auth.users (id) on delete cascade,
  name         text not null,
  package_size text not null,
  price        numeric(10, 2) not null,
  stock        integer not null default 0,
  status       text not null default 'active',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  constraint products_name_length   check (char_length(btrim(name)) between 1 and 60),
  constraint products_size_length   check (char_length(btrim(package_size)) between 1 and 20),
  constraint products_price_positive check (price > 0),
  constraint products_stock_not_negative check (stock >= 0),
  constraint products_status_valid  check (status in ('active', 'inactive')),
  -- lets orders reference a product together with its owner, so an order can never point at another user's product
  constraint products_id_user_unique unique (id, user_id)
);
create index products_user_id_idx on public.products (user_id);

-- ---------------------------------------------------------------------------
-- Orders
-- Product name, size and price are copied onto the order so past orders keep their record
-- when a product is edited or deleted.
-- ---------------------------------------------------------------------------
create table public.orders (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null default auth.uid() references auth.users (id) on delete cascade,
  order_number  integer not null,
  product_id    uuid,
  product_name  text not null,
  package_size  text not null,
  unit_price    numeric(10, 2) not null,
  quantity      integer not null,
  total_price   numeric(12, 2) not null,
  customer_name text not null,
  status        text not null default 'pending',
  order_date    date not null default current_date,
  created_at    timestamptz not null default now(),
  constraint orders_number_unique   unique (user_id, order_number),
  constraint orders_product_owner_fk foreign key (product_id, user_id)
    references public.products (id, user_id) on delete set null (product_id),
  constraint orders_customer_length check (char_length(btrim(customer_name)) between 1 and 60),
  constraint orders_quantity_positive check (quantity >= 1),
  constraint orders_unit_price_positive check (unit_price > 0),
  constraint orders_status_valid    check (status in ('pending', 'processing', 'completed'))
);
create index orders_user_date_idx on public.orders (user_id, order_date desc, order_number desc);

-- ---------------------------------------------------------------------------
-- Triggers
-- ---------------------------------------------------------------------------
create function public.touch_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin
  new.updated_at := now();
  return new;
end $$;

create trigger products_touch_updated_at
  before update on public.products
  for each row execute function public.touch_updated_at();

create function public.orders_set_total() returns trigger
language plpgsql set search_path = '' as $$
begin
  new.total_price := round(new.unit_price * new.quantity, 2);
  return new;
end $$;

create trigger orders_set_total
  before insert or update on public.orders
  for each row execute function public.orders_set_total();

-- ---------------------------------------------------------------------------
-- Row-Level Security
-- No policy exists for the anon role, so signed-out requests read and write nothing.
-- ---------------------------------------------------------------------------
alter table public.products enable row level security;
alter table public.orders   enable row level security;

create policy products_select_own on public.products
  for select to authenticated using (user_id = (select auth.uid()));
create policy products_insert_own on public.products
  for insert to authenticated with check (user_id = (select auth.uid()));
create policy products_update_own on public.products
  for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));
create policy products_delete_own on public.products
  for delete to authenticated using (user_id = (select auth.uid()));

create policy orders_select_own on public.orders
  for select to authenticated using (user_id = (select auth.uid()));
create policy orders_update_own on public.orders
  for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));
-- Orders are created only through create_order() below, so there is no insert policy.

-- ---------------------------------------------------------------------------
-- Privileges: start from nothing, then grant only what the app needs.
-- Column grants stop a client from editing user_id, prices or quantities after the fact.
-- ---------------------------------------------------------------------------
revoke all on public.products from anon, authenticated;
revoke all on public.orders   from anon, authenticated;

grant select, delete on public.products to authenticated;
grant insert (name, package_size, price, stock, status) on public.products to authenticated;
grant update (name, package_size, price, stock, status) on public.products to authenticated;

grant select on public.orders to authenticated;
grant update (status) on public.orders to authenticated;

-- ---------------------------------------------------------------------------
-- create_order(): validates the input, checks stock, lowers stock and inserts the order in one step.
-- SECURITY DEFINER lets it insert despite the missing insert policy, so it checks auth.uid() itself
-- and only ever touches rows owned by the caller.
-- ---------------------------------------------------------------------------
create function public.create_order(
  p_product_id    uuid,
  p_customer_name text,
  p_quantity      integer,
  p_status        text default 'pending',
  p_order_date    date default current_date
) returns public.orders
language plpgsql security definer set search_path = '' as $$
declare
  v_user     uuid := auth.uid();
  v_customer text := btrim(coalesce(p_customer_name, ''));
  v_product  public.products;
  v_number   integer;
  v_order    public.orders;
begin
  if v_user is null then
    raise exception 'You must be signed in.' using errcode = '28000';
  end if;
  if char_length(v_customer) not between 1 and 60 then
    raise exception 'Customer name must be 1 to 60 characters.' using errcode = '22023';
  end if;
  if p_quantity is null or p_quantity < 1 then
    raise exception 'Quantity must be at least 1.' using errcode = '22023';
  end if;
  if p_status is null or p_status not in ('pending', 'processing', 'completed') then
    raise exception 'Status must be pending, processing or completed.' using errcode = '22023';
  end if;
  if p_order_date is null then
    raise exception 'Order date is required.' using errcode = '22023';
  end if;

  select * into v_product
  from public.products
  where id = p_product_id and user_id = v_user
  for update;
  if not found then
    raise exception 'Product not found.' using errcode = 'P0002';
  end if;
  if v_product.status <> 'active' then
    raise exception 'This product is inactive.' using errcode = '22023';
  end if;
  if v_product.stock < p_quantity then
    raise exception 'Only % packs are in stock.', v_product.stock using errcode = '23514';
  end if;

  perform pg_advisory_xact_lock(hashtextextended(v_user::text, 0));
  select coalesce(max(order_number), 1000) + 1 into v_number
  from public.orders where user_id = v_user;

  update public.products set stock = stock - p_quantity where id = v_product.id;

  insert into public.orders (
    user_id, order_number, product_id, product_name, package_size, unit_price,
    quantity, total_price, customer_name, status, order_date
  ) values (
    v_user, v_number, v_product.id, v_product.name, v_product.package_size, v_product.price,
    p_quantity, round(v_product.price * p_quantity, 2), v_customer, p_status, p_order_date
  ) returning * into v_order;

  return v_order;
end $$;

revoke all on function public.create_order(uuid, text, integer, text, date) from public, anon;
grant execute on function public.create_order(uuid, text, integer, text, date) to authenticated;

-- ---------------------------------------------------------------------------
-- Sales records: completed orders. security_invoker makes the view obey the caller's RLS.
-- ---------------------------------------------------------------------------
create view public.sales_records with (security_invoker = true) as
  select id, user_id, order_number, product_name, package_size, customer_name,
         quantity, unit_price, total_price, order_date
  from public.orders
  where status = 'completed';

revoke all on public.sales_records from anon, authenticated;
grant select on public.sales_records to authenticated;
