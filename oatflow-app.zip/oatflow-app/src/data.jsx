import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { supabase } from './lib/supabase.js';
import { friendlyError } from './lib/format.js';

// Holds the signed-in user's products, orders and sales records.
// It is mounted with key={user.id}, so signing out (or signing in as someone else) throws all of it away.
// Nothing here filters by user: the database's Row-Level Security returns only the caller's own rows.
const DataContext = createContext(null);

export function DataProvider({ children }) {
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [sales, setSales] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const alive = useRef(true);

  const load = useCallback(async () => {
    const [p, o, s] = await Promise.all([
      supabase.from('products').select('*').order('name', { ascending: true }),
      supabase.from('orders').select('*').order('order_date', { ascending: false }).order('order_number', { ascending: false }),
      supabase.from('sales_records').select('*').order('order_date', { ascending: false }).order('order_number', { ascending: false })
    ]);
    if (!alive.current) return;
    const failed = p.error || o.error || s.error;
    if (failed) {
      setError(friendlyError(failed));
    } else {
      setError('');
      setProducts(p.data);
      setOrders(o.data);
      setSales(s.data);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    alive.current = true;
    load();
    return () => { alive.current = false; };
  }, [load]);

  // Each action returns { error } with a readable message, or { error: '' } on success.
  const run = useCallback(async (request) => {
    const { error: err } = await request;
    if (err) return { error: friendlyError(err) };
    await load();
    return { error: '' };
  }, [load]);

  const actions = useMemo(() => ({
    reload: load,
    addProduct: (v) => run(supabase.from('products').insert({
      name: v.name, package_size: v.package_size, price: v.price, stock: v.stock, status: v.status
    })),
    updateProduct: (id, v) => run(supabase.from('products').update({
      name: v.name, package_size: v.package_size, price: v.price, stock: v.stock, status: v.status
    }).eq('id', id)),
    deleteProduct: (id) => run(supabase.from('products').delete().eq('id', id)),
    createOrder: (v) => run(supabase.rpc('create_order', {
      p_product_id: v.product_id, p_customer_name: v.customer_name, p_quantity: v.quantity,
      p_status: v.status, p_order_date: v.order_date
    })),
    setOrderStatus: (id, status) => run(supabase.from('orders').update({ status }).eq('id', id))
  }), [load, run]);

  const value = useMemo(() => ({ products, orders, sales, loading, error, ...actions }), [products, orders, sales, loading, error, actions]);
  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used inside DataProvider');
  return ctx;
}
