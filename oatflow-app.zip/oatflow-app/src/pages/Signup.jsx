import { useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase.js';
import { Field, ErrorBanner } from '../components/ui.jsx';
import AuthShell, { EMAIL_RE, authMessage } from './AuthForm.jsx';

export default function Signup() {
  const [errs, setErrs] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);
  const [sentTo, setSentTo] = useState('');

  async function onSubmit(e) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const name = String(f.get('name') || '').trim();
    const email = String(f.get('email') || '').trim();
    const password = String(f.get('password') || '');
    const next = {};
    if (!name) next.name = 'Enter your name.';
    else if (name.length > 60) next.name = 'Use 60 characters or fewer.';
    if (!EMAIL_RE.test(email)) next.email = 'Enter a valid email address.';
    if (password.length < 8) next.password = 'Use at least 8 characters.';
    setErrs(next);
    setFormError('');
    if (Object.keys(next).length) return;
    setBusy(true);
    const { data, error } = await supabase.auth.signUp({
      email, password, options: { data: { display_name: name } }
    });
    setBusy(false);
    if (error) { setFormError(authMessage(error)); return; }
    // With email confirmation on, there is no session yet: ask the person to check their inbox.
    if (!data.session) setSentTo(email);
  }

  if (sentTo) {
    return (
      <AuthShell title="Check your email" sub={'We sent a confirmation link to ' + sentTo + '. Open it, then log in.'}
        footer={<Link className="link" to="/login">Back to log in</Link>} />
    );
  }

  return (
    <AuthShell
      title="Create your account"
      sub="Your products, orders and sales stay private to your account."
      footer={<>Already have an account? <Link className="link" to="/login">Log in</Link></>}
    >
      <form className="auth-form" onSubmit={onSubmit} noValidate>
        <ErrorBanner>{formError}</ErrorBanner>
        <Field id="name" label="Name" error={errs.name}>
          <input id="name" name="name" type="text" autoComplete="name" maxLength={60} aria-invalid={errs.name ? 'true' : undefined} aria-describedby="name-err" />
        </Field>
        <Field id="email" label="Email" error={errs.email}>
          <input id="email" name="email" type="email" autoComplete="email" aria-invalid={errs.email ? 'true' : undefined} aria-describedby="email-err" />
        </Field>
        <Field id="password" label="Password" error={errs.password} hint="At least 8 characters.">
          <input id="password" name="password" type="password" autoComplete="new-password" aria-invalid={errs.password ? 'true' : undefined} aria-describedby="password-hint password-err" />
        </Field>
        <button type="submit" className="btn primary block" disabled={busy}>{busy ? 'Creating account…' : 'Create account'}</button>
      </form>
    </AuthShell>
  );
}
