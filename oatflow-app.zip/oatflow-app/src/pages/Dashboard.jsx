import { Link } from 'react-router-dom';
import { useData } from '../data.jsx';
import { useAuth } from '../auth.jsx';
import { Icon, Kpi, PageHead, Empty } from '../components/ui.jsx';
import { OrdersTable } from './Orders.jsx';
import { formatMoney, formatNumber } from '../lib/format.js';

export function computeStats(products, orders, sales) {
  const revenue = sales.reduce((a, s) => a + Number(s.total_price), 0);
  const groups = new Map();
  sales.forEach((s) => {
    const k = s.product_name + '|' + s.package_size;
    const g = groups.get(k) || { name: s.product_name, size: s.package_size, units: 0, revenue: 0 };
    g.units += s.quantity;
    g.revenue += Number(s.total_price);
    groups.set(k, g);
  });
  const byProduct = Array.from(groups.values());
  const active = products.filter((p) => p.status === 'active');
  const open = orders.filter((o) => o.status !== 'completed');
  return {
    revenue,
    completed: sales.length,
    totalOrders: orders.length,
    pending: orders.filter((o) => o.status === 'pending').length,
    processing: orders.filter((o) => o.status === 'processing').length,
    openValue: open.reduce((a, o) => a + Number(o.total_price), 0),
    openCount: open.length,
    avg: sales.length ? revenue / sales.length : 0,
    stock: active.reduce((a, p) => a + p.stock, 0),
    activeCount: active.length,
    best: byProduct.slice().sort((a, b) => b.units - a.units)[0] || null,
    byProduct: byProduct.sort((a, b) => b.revenue - a.revenue)
  };
}

export default function Dashboard() {
  const { products, orders, sales } = useData();
  const { displayName } = useAuth();
  const s = computeStats(products, orders, sales);
  const recent = orders.slice(0, 8);
  const today = new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });

  return (
    <>
      <PageHead
        title="Dashboard"
        sub={'Hello, ' + displayName + ' · ' + today}
        actions={<Link className="btn primary" to="/orders?new=1"><Icon name="plus" />New order</Link>}
      />
      <section className="kpis" aria-label="Key metrics">
        <Kpi label="Total Sales" icon="sales" value={formatMoney(s.revenue)} sub={'From ' + s.completed + ' completed orders'} />
        <Kpi label="Total Orders" icon="orders" value={formatNumber(s.totalOrders)} sub={s.pending + ' pending · ' + s.processing + ' processing'} />
        <Kpi label="Available Oats Stock" icon="products" value={<>{formatNumber(s.stock)}<small>packs</small></>} sub={'Across ' + s.activeCount + ' active products'} />
        <Kpi label="Best-Selling Oats" icon="star" text
          value={s.best ? s.best.name : 'No sales yet'}
          sub={s.best ? s.best.size + ' · ' + formatNumber(s.best.units) + ' units sold' : 'Completed orders will appear here'} />
      </section>
      <section className="card">
        <div className="card-head"><h2>Recent sales</h2><Link className="link" to="/orders">View all orders</Link></div>
        {recent.length ? <OrdersTable list={recent} /> : (
          <Empty title="No orders yet" action={<Link className="btn primary" to="/orders?new=1"><Icon name="plus" />Create your first order</Link>}>
            Add a product, then create an order to see it here.
          </Empty>
        )}
      </section>
    </>
  );
}
