import { useData } from '../data.jsx';
import { Kpi, PageHead, Empty } from '../components/ui.jsx';
import { computeStats } from './Dashboard.jsx';
import { formatDate, formatMoney, formatNumber, orderCode } from '../lib/format.js';

export default function Sales() {
  const { products, orders, sales } = useData();
  const s = computeStats(products, orders, sales);
  const maxRev = s.byProduct.length ? s.byProduct[0].revenue : 1;

  return (
    <>
      <PageHead title="Sales" sub="View your sales records and revenue" />
      <section className="kpis" aria-label="Revenue summary">
        <Kpi label="Revenue" icon="sales" value={formatMoney(s.revenue)} sub="From completed orders" />
        <Kpi label="Completed orders" icon="orders" value={formatNumber(s.completed)} sub="Counted as sales" />
        <Kpi label="Average order" icon="star" value={formatMoney(Math.round(s.avg * 100) / 100)} sub="Revenue per completed order" />
        <Kpi label="Still in progress" icon="products" value={formatMoney(s.openValue)} sub={s.openCount + ' pending or processing'} />
      </section>
      <section className="card">
        <div className="card-head"><h2>Revenue by product</h2></div>
        <div className="card-body">
          {s.byProduct.length ? (
            <ul className="bars">
              {s.byProduct.map((g) => (
                <li key={g.name + g.size}>
                  <div className="bar-row"><span>{g.name}<em>{g.size} · {formatNumber(g.units)} sold</em></span><span className="bar-val">{formatMoney(g.revenue)}</span></div>
                  <div className="bar-track"><div className="bar-fill" style={{ width: Math.max(3, Math.round((g.revenue / maxRev) * 100)) + '%' }} /></div>
                </li>
              ))}
            </ul>
          ) : <Empty title="No revenue yet">Complete an order to record a sale.</Empty>}
        </div>
      </section>
      <section className="card">
        <div className="card-head"><h2>Sales records</h2></div>
        {sales.length ? (
          <div className="table-wrap">
            <table className="tbl">
              <thead><tr><th>Order ID</th><th>Date</th><th>Customer</th><th>Product</th><th className="num">Quantity</th><th className="num">Revenue</th></tr></thead>
              <tbody>
                {sales.map((o) => (
                  <tr key={o.id}>
                    <td className="lead nowrap" data-label="Order ID"><span className="id">{orderCode(o.order_number)}</span></td>
                    <td className="nowrap" data-label="Date">{formatDate(o.order_date)}</td>
                    <td data-label="Customer">{o.customer_name}</td>
                    <td data-label="Product"><div className="cell-stack"><div className="cell-main">{o.product_name}</div><div className="cell-sub">{o.package_size}</div></div></td>
                    <td className="num" data-label="Quantity">{formatNumber(o.quantity)}</td>
                    <td className="num" data-label="Revenue"><strong>{formatMoney(o.total_price)}</strong></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : <Empty title="No sales records">Orders marked Completed are recorded here.</Empty>}
      </section>
    </>
  );
}
