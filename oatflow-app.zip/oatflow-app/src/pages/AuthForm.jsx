import { Logo } from '../components/ui.jsx';

export default function AuthShell({ title, sub, children, footer }) {
  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <div className="auth-brand"><Logo /><span>OatFlow</span></div>
        <h1>{title}</h1>
        <p className="auth-sub">{sub}</p>
        {children}
        <p className="auth-foot">{footer}</p>
      </div>
    </div>
  );
}

export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Supabase auth errors to plain language. Sign-in never says whether the email exists.
export function authMessage(error) {
  const m = (error && error.message) || '';
  if (/invalid login credentials/i.test(m)) return 'Email or password is incorrect.';
  if (/email not confirmed/i.test(m)) return 'Confirm your email first. Check your inbox for the link.';
  if (/already registered|already been registered/i.test(m)) return 'That email may already have an account. Try logging in instead.';
  if (/rate limit|too many/i.test(m)) return 'Too many attempts. Wait a minute and try again.';
  if (/password/i.test(m) && /(weak|short|least|characters)/i.test(m)) return 'Choose a stronger password with at least 8 characters.';
  if (/failed to fetch|network/i.test(m)) return 'Could not reach the server. Check your connection and try again.';
  return 'Something went wrong. Try again.';
}
