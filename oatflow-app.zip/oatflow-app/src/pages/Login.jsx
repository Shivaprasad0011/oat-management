import { useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase.js';
import { Field, ErrorBanner } from '../components/ui.jsx';
import AuthShell, { EMAIL_RE, authMessage } from './AuthForm.jsx';

export default function Login() {
  const [errs, setErrs] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const email = String(f.get('email') || '').trim();
    const password = String(f.get('password') || '');
    const next = {};
    if (!EMAIL_RE.test(email)) next.email = 'Enter a valid email address.';
    if (!password) next.password = 'Enter your password.';
    setErrs(next);
    setFormError('');
    if (Object.keys(next).length) return;
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) setFormError(authMessage(error));
    // On success the auth listener updates the session and the router redirects.
  }

  return (
    <AuthShell
      title="Log in"
      sub="Welcome back. Log in to manage your oats sales."
      footer={<>New to OatFlow? <Link className="link" to="/signup">Create an account</Link></>}
    >
      <form className="auth-form" onSubmit={onSubmit} noValidate>
        <ErrorBanner>{formError}</ErrorBanner>
        <Field id="email" label="Email" error={errs.email}>
          <input id="email" name="email" type="email" autoComplete="email" aria-invalid={errs.email ? 'true' : undefined} aria-describedby="email-err" />
        </Field>
        <Field id="password" label="Password" error={errs.password}>
          <input id="password" name="password" type="password" autoComplete="current-password" aria-invalid={errs.password ? 'true' : undefined} aria-describedby="password-err" />
        </Field>
        <button type="submit" className="btn primary block" disabled={busy}>{busy ? 'Logging in…' : 'Log in'}</button>
      </form>
    </AuthShell>
  );
}
