import { useState } from 'react';
import { useOutletContext } from 'react-router-dom';
import { useData } from '../data.jsx';
import { Icon, Pill, PageHead, Empty, Field, Modal, ErrorBanner } from '../components/ui.jsx';
import { currencySymbol, formatMoney, formatNumber, productStatus } from '../lib/format.js';

const SIZES = ['250 g', '500 g', '750 g', '1 kg', '2 kg', '5 kg', '10 × 40 g'];

function ProductForm({ product, onClose, onToast }) {
  const { addProduct, updateProduct } = useData();
  const [errs, setErrs] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);
  const bad = (k) => (errs[k] ? 'true' : undefined);

  async function onSubmit(e) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const name = String(f.get('name') || '').trim();
    const size = String(f.get('size') || '').trim();
    const priceRaw = String(f.get('price') || '').trim();
    const stockRaw = String(f.get('stock') || '').trim();
    const status = f.get('status') === 'inactive' ? 'inactive' : 'active';
    const price = Number(priceRaw);
    const stock = Number(stockRaw);
    const next = {};
    if (!name) next.name = 'Enter a product name.';
    else if (name.length > 60) next.name = 'Use 60 characters or fewer.';
    if (!size) next.size = 'Enter a package size, for example 1 kg.';
    else if (size.length > 20) next.size = 'Use 20 characters or fewer.';
    if (priceRaw === '' || !Number.isFinite(price) || price <= 0) next.price = 'Enter a price above 0.';
    else if (price >= 100000000) next.price = 'That price is too large.';
    if (stockRaw === '' || !Number.isInteger(stock) || stock < 0) next.stock = 'Enter a whole number of packs, 0 or more.';
    else if (stock > 100000000) next.stock = 'That stock number is too large.';
    setErrs(next);
    setFormError('');
    if (Object.keys(next).length) return;
    setBusy(true);
    const values = { name, package_size: size, price: Math.round(price * 100) / 100, stock, status };
    const { error } = product ? await updateProduct(product.id, values) : await addProduct(values);
    setBusy(false);
    if (error) { setFormError(error); return; }
    onToast(product ? 'Product updated' : 'Product added');
    onClose();
  }

  return (
    <Modal title={product ? 'Edit product' : 'Add product'} onClose={onClose}>
      <form onSubmit={onSubmit} noValidate>
        <div className="modal-body">
          <ErrorBanner>{formError}</ErrorBanner>
          <Field id="pf-name" label="Product name" error={errs.name}>
            <input id="pf-name" name="name" type="text" maxLength={60} autoComplete="off" defaultValue={product ? product.name : ''} placeholder="e.g. Classic Rolled Oats" aria-invalid={bad('name')} aria-describedby="pf-name-err" data-autofocus />
          </Field>
          <div className="row2">
            <Field id="pf-size" label="Package size" error={errs.size}>
              <input id="pf-size" name="size" type="text" maxLength={20} autoComplete="off" list="pf-sizes" defaultValue={product ? product.package_size : ''} placeholder="e.g. 1 kg" aria-invalid={bad('size')} aria-describedby="pf-size-err" />
              <datalist id="pf-sizes">{SIZES.map((s) => <option key={s} value={s} />)}</datalist>
            </Field>
            <Field id="pf-price" label="Price" error={errs.price}>
              <div className="affix-wrap">
                <span className="affix">{currencySymbol()}</span>
                <input id="pf-price" name="price" type="number" min="0" step="0.01" inputMode="decimal" defaultValue={product ? product.price : ''} aria-invalid={bad('price')} aria-describedby="pf-price-err" />
              </div>
            </Field>
          </div>
          <div className="row2">
            <Field id="pf-stock" label="Available stock (packs)" error={errs.stock}>
              <input id="pf-stock" name="stock" type="number" min="0" step="1" inputMode="numeric" defaultValue={product ? product.stock : ''} aria-invalid={bad('stock')} aria-describedby="pf-stock-err" />
            </Field>
            <Field id="pf-status" label="Status">
              <select id="pf-status" name="status" defaultValue={product ? product.status : 'active'}>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </Field>
          </div>
          <p className="hint">Low Stock and Out of Stock are applied automatically from the stock level.</p>
        </div>
        <div className="modal-foot">
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn primary" disabled={busy}>{busy ? 'Saving…' : product ? 'Save changes' : 'Add product'}</button>
        </div>
      </form>
    </Modal>
  );
}

function ConfirmDelete({ product, onClose, onToast }) {
  const { deleteProduct } = useData();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function confirm() {
    setBusy(true);
    const res = await deleteProduct(product.id);
    setBusy(false);
    if (res.error) { setError(res.error); return; }
    onToast('Product deleted');
    onClose();
  }

  return (
    <Modal title="Delete product?" onClose={onClose}>
      <div className="modal-body">
        <ErrorBanner>{error}</ErrorBanner>
        <p className="confirm-text">{product.name} ({product.package_size}) will be removed from your product list. Past orders keep their records.</p>
      </div>
      <div className="modal-foot">
        <button type="button" className="btn" onClick={onClose} data-autofocus>Cancel</button>
        <button type="button" className="btn danger solid" onClick={confirm} disabled={busy}>{busy ? 'Deleting…' : 'Delete product'}</button>
      </div>
    </Modal>
  );
}

export default function Products() {
  const { toast } = useOutletContext();
  const { products } = useData();
  const [dialog, setDialog] = useState(null);
  const close = () => setDialog(null);

  return (
    <>
      <PageHead title="Products" sub="View and manage your oats products"
        actions={<button type="button" className="btn primary" onClick={() => setDialog({ kind: 'form', product: null })}><Icon name="plus" />Add product</button>} />
      <section className="card">
        {products.length ? (
          <div className="table-wrap">
            <table className="tbl">
              <thead>
                <tr><th>Product Name</th><th>Package Size</th><th className="num">Price</th><th className="num">Available Stock</th><th>Product Status</th><th className="actions"><span className="sr">Actions</span></th></tr>
              </thead>
              <tbody>
                {products.map((p) => {
                  const st = productStatus(p);
                  return (
                    <tr key={p.id}>
                      <td className="lead" data-label="Product Name"><div className="cell-main">{p.name}</div></td>
                      <td className="nowrap" data-label="Package Size">{p.package_size}</td>
                      <td className="num" data-label="Price">{formatMoney(p.price)}</td>
                      <td className="num" data-label="Available Stock">{formatNumber(p.stock)} <span className="unit">packs</span></td>
                      <td data-label="Product Status"><Pill cls={st.cls}>{st.label}</Pill></td>
                      <td className="actions">
                        <button type="button" className="btn sm" onClick={() => setDialog({ kind: 'form', product: p })} aria-label={'Edit ' + p.name + ' ' + p.package_size}><Icon name="edit" />Edit</button>
                        <button type="button" className="btn sm danger" onClick={() => setDialog({ kind: 'delete', product: p })} aria-label={'Delete ' + p.name + ' ' + p.package_size}><Icon name="trash" />Delete</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <Empty title="No products yet" action={<button type="button" className="btn primary" onClick={() => setDialog({ kind: 'form', product: null })}><Icon name="plus" />Add your first product</button>}>
            Add an oats product to start taking orders.
          </Empty>
        )}
      </section>
      {dialog && dialog.kind === 'form' ? <ProductForm product={dialog.product} onClose={close} onToast={toast} /> : null}
      {dialog && dialog.kind === 'delete' ? <ConfirmDelete product={dialog.product} onClose={close} onToast={toast} /> : null}
    </>
  );
}
