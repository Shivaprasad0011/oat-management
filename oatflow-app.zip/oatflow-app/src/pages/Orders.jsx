import { useEffect, useState } from 'react';
import { useOutletContext, useSearchParams } from 'react-router-dom';
import { useData } from '../data.jsx';
import { Icon, OrderPill, PageHead, Empty, Field, Modal, ErrorBanner } from '../components/ui.jsx';
import { ORDER_STATUSES, STATUS_CLASS, STATUS_LABEL, formatDate, formatMoney, formatNumber, orderCode, todayISO } from '../lib/format.js';

function StatusSelect({ order }) {
  const { setOrderStatus } = useData();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function onChange(e) {
    setBusy(true);
    setError('');
    const res = await setOrderStatus(order.id, e.target.value);
    setBusy(false);
    if (res.error) setError(res.error);
  }

  return (
    <>
      <select className={'status-select ' + STATUS_CLASS[order.status]} value={order.status} onChange={onChange} disabled={busy}
        aria-label={'Status for order ' + orderCode(order.order_number)}>
        {ORDER_STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
      </select>
      {error ? <div className="err" role="alert">{error}</div> : null}
    </>
  );
}

export function OrdersTable({ list, editable }) {
  return (
    <div className="table-wrap">
      <table className="tbl">
        <thead>
          <tr><th>Order ID</th><th>Product Name</th><th>Customer Name</th><th className="num">Quantity</th><th className="num">Total Price</th><th>Order Status</th><th>Order Date</th></tr>
        </thead>
        <tbody>
          {list.map((o) => (
            <tr key={o.id}>
              <td className="lead nowrap" data-label="Order ID"><span className="id">{orderCode(o.order_number)}</span></td>
              <td data-label="Product Name">
                <div className="cell-stack"><div className="cell-main">{o.product_name}</div><div className="cell-sub">{o.package_size} · {formatMoney(o.unit_price)} each</div></div>
              </td>
              <td data-label="Customer Name">{o.customer_name}</td>
              <td className="num" data-label="Quantity">{formatNumber(o.quantity)}</td>
              <td className="num" data-label="Total Price"><strong>{formatMoney(o.total_price)}</strong></td>
              <td data-label="Order Status">{editable ? <StatusSelect order={o} /> : <OrderPill status={o.status} />}</td>
              <td className="nowrap" data-label="Order Date">{formatDate(o.order_date)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function OrderForm({ onClose, onToast }) {
  const { products, createOrder } = useData();
  const available = products.filter((p) => p.status === 'active' && p.stock > 0);
  const [productId, setProductId] = useState(available.length ? available[0].id : '');
  const [qty, setQty] = useState('1');
  const [errs, setErrs] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);
  const product = available.find((p) => p.id === productId);
  const qtyNum = Number(qty);
  const total = product && Number.isInteger(qtyNum) && qtyNum > 0 ? product.price * qtyNum : 0;
  const bad = (k) => (errs[k] ? 'true' : undefined);

  async function onSubmit(e) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const customer = String(f.get('customer') || '').trim();
    const date = String(f.get('date') || '');
    const status = String(f.get('status') || 'pending');
    const next = {};
    if (!customer) next.customer = 'Enter the customer name.';
    else if (customer.length > 60) next.customer = 'Use 60 characters or fewer.';
    if (!product) next.product = 'Choose a product.';
    if (qty === '' || !Number.isInteger(qtyNum) || qtyNum < 1) next.qty = 'Enter a whole quantity of 1 or more.';
    else if (product && qtyNum > product.stock) next.qty = 'Only ' + product.stock + ' packs are in stock.';
    if (!date) next.date = 'Pick an order date.';
    if (!ORDER_STATUSES.includes(status)) next.status = 'Choose a status.';
    setErrs(next);
    setFormError('');
    if (Object.keys(next).length) return;
    setBusy(true);
    const { error } = await createOrder({ product_id: product.id, customer_name: customer, quantity: qtyNum, status, order_date: date });
    setBusy(false);
    if (error) { setFormError(error); return; }
    onToast('Order created');
    onClose();
  }

  if (!available.length) {
    return (
      <Modal title="New order" onClose={onClose}>
        <div className="modal-body"><p className="confirm-text">No products are available to sell. Add an active product with stock, then create the order.</p></div>
        <div className="modal-foot"><button type="button" className="btn primary" onClick={onClose} data-autofocus>Got it</button></div>
      </Modal>
    );
  }

  return (
    <Modal title="New order" onClose={onClose}>
      <form onSubmit={onSubmit} noValidate>
        <div className="modal-body">
          <ErrorBanner>{formError}</ErrorBanner>
          <Field id="of-customer" label="Customer name" error={errs.customer}>
            <input id="of-customer" name="customer" type="text" maxLength={60} autoComplete="off" placeholder="e.g. Sunrise Café" aria-invalid={bad('customer')} aria-describedby="of-customer-err" data-autofocus />
          </Field>
          <Field id="of-product" label="Product" error={errs.product} hint={product ? formatNumber(product.stock) + ' packs in stock' : ''}>
            <select id="of-product" value={productId} onChange={(e) => setProductId(e.target.value)} aria-describedby="of-product-hint of-product-err">
              {available.map((p) => <option key={p.id} value={p.id}>{p.name} · {p.package_size}</option>)}
            </select>
          </Field>
          <div className="row2">
            <Field id="of-qty" label="Quantity (packs)" error={errs.qty}>
              <input id="of-qty" type="number" min="1" step="1" inputMode="numeric" value={qty} onChange={(e) => setQty(e.target.value)} aria-invalid={bad('qty')} aria-describedby="of-qty-err" />
            </Field>
            <Field id="of-date" label="Order date" error={errs.date}>
              <input id="of-date" name="date" type="date" defaultValue={todayISO()} aria-invalid={bad('date')} aria-describedby="of-date-err" />
            </Field>
          </div>
          <Field id="of-status" label="Status" error={errs.status}>
            <select id="of-status" name="status" defaultValue="pending">
              {ORDER_STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
            </select>
          </Field>
          <div className="summary"><span>{product ? formatMoney(product.price) + ' per pack' : ''}</span><strong>{formatMoney(total)}</strong></div>
        </div>
        <div className="modal-foot">
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn primary" disabled={busy}>{busy ? 'Creating…' : 'Create order'}</button>
        </div>
      </form>
    </Modal>
  );
}

export default function Orders() {
  const { toast } = useOutletContext();
  const { orders } = useData();
  const [params, setParams] = useSearchParams();
  const [filter, setFilter] = useState('all');
  const [creating, setCreating] = useState(params.get('new') === '1');

  useEffect(() => {
    if (params.get('new') === '1') {
      setCreating(true);
      setParams({}, { replace: true });
    }
  }, [params, setParams]);

  const filters = ['all', ...ORDER_STATUSES];
  const count = (f) => (f === 'all' ? orders.length : orders.filter((o) => o.status === f).length);
  const list = filter === 'all' ? orders : orders.filter((o) => o.status === filter);

  return (
    <>
      <PageHead title="Orders" sub="Create and track customer orders"
        actions={<button type="button" className="btn primary" onClick={() => setCreating(true)}><Icon name="plus" />New order</button>} />
      <div className="filters" role="group" aria-label="Filter orders by status">
        {filters.map((f) => (
          <button key={f} type="button" className="chip-btn" aria-pressed={filter === f} onClick={() => setFilter(f)}>
            {f === 'all' ? 'All' : STATUS_LABEL[f]}<span>{count(f)}</span>
          </button>
        ))}
      </div>
      <section className="card">
        {list.length ? <OrdersTable list={list} editable /> : (
          <Empty title={filter === 'all' ? 'No orders yet' : 'No ' + STATUS_LABEL[filter].toLowerCase() + ' orders'}>
            {filter === 'all' ? 'Create an order to get started.' : 'Orders with this status will show up here.'}
          </Empty>
        )}
      </section>
      {creating ? <OrderForm onClose={() => setCreating(false)} onToast={toast} /> : null}
    </>
  );
}
