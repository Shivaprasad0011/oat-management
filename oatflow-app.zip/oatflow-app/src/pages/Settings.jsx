import { useState } from 'react';
import { supabase } from '../lib/supabase.js';
import { useAuth } from '../auth.jsx';
import { PageHead, Field, ErrorBanner } from '../components/ui.jsx';
import { EMAIL_RE, authMessage } from './AuthForm.jsx';
import { useSignOut } from '../components/Layout.jsx';

function Notice({ kind, children }) {
  if (!children) return null;
  return <div className={'banner ' + kind} role={kind === 'bad' ? 'alert' : 'status'}>{children}</div>;
}

function NameForm() {
  const { displayName } = useAuth();
  const [err, setErr] = useState('');
  const [formError, setFormError] = useState('');
  const [ok, setOk] = useState('');
  const [busy, setBusy] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    const name = String(new FormData(e.currentTarget).get('name') || '').trim();
    setOk(''); setFormError('');
    if (!name) { setErr('Enter your name.'); return; }
    if (name.length > 60) { setErr('Use 60 characters or fewer.'); return; }
    setErr('');
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ data: { display_name: name } });
    setBusy(false);
    if (error) setFormError(authMessage(error)); else setOk('Display name updated.');
  }

  return (
    <form className="form-section" onSubmit={onSubmit} noValidate>
      <h2>Display name</h2>
      <Notice kind="bad">{formError}</Notice>
      <Notice kind="ok">{ok}</Notice>
      <Field id="st-name" label="Name" error={err}>
        <input id="st-name" name="name" type="text" maxLength={60} defaultValue={displayName} autoComplete="name" aria-invalid={err ? 'true' : undefined} aria-describedby="st-name-err" />
      </Field>
      <div><button type="submit" className="btn primary" disabled={busy}>{busy ? 'Saving…' : 'Save name'}</button></div>
    </form>
  );
}

function EmailForm() {
  const { user } = useAuth();
  const [err, setErr] = useState('');
  const [formError, setFormError] = useState('');
  const [ok, setOk] = useState('');
  const [busy, setBusy] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    const email = String(new FormData(e.currentTarget).get('email') || '').trim();
    setOk(''); setFormError('');
    if (!EMAIL_RE.test(email)) { setErr('Enter a valid email address.'); return; }
    if (email.toLowerCase() === (user.email || '').toLowerCase()) { setErr('That is already your email address.'); return; }
    setErr('');
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ email });
    setBusy(false);
    if (error) setFormError(authMessage(error));
    else setOk('Check your inbox. Your email changes after you confirm using the link we sent. Until then, keep using your current email.');
  }

  return (
    <form className="form-section" onSubmit={onSubmit} noValidate>
      <h2>Email address</h2>
      <p className="hint">Current email: {user.email}</p>
      <Notice kind="bad">{formError}</Notice>
      <Notice kind="ok">{ok}</Notice>
      <Field id="st-email" label="New email" error={err}>
        <input id="st-email" name="email" type="email" autoComplete="email" aria-invalid={err ? 'true' : undefined} aria-describedby="st-email-err" />
      </Field>
      <div><button type="submit" className="btn primary" disabled={busy}>{busy ? 'Sending…' : 'Send confirmation'}</button></div>
    </form>
  );
}

function PasswordForm() {
  const { user } = useAuth();
  const [errs, setErrs] = useState({});
  const [formError, setFormError] = useState('');
  const [ok, setOk] = useState('');
  const [busy, setBusy] = useState(false);
  const bad = (k) => (errs[k] ? 'true' : undefined);

  async function onSubmit(e) {
    e.preventDefault();
    const form = e.currentTarget;
    const f = new FormData(form);
    const current = String(f.get('current') || '');
    const next = String(f.get('next') || '');
    const confirm = String(f.get('confirm') || '');
    const problems = {};
    setOk(''); setFormError('');
    if (!current) problems.current = 'Enter your current password.';
    if (next.length < 8) problems.next = 'Use at least 8 characters.';
    else if (next === current) problems.next = 'Choose a password different from the current one.';
    if (confirm !== next) problems.confirm = 'The passwords do not match.';
    setErrs(problems);
    if (Object.keys(problems).length) return;
    setBusy(true);
    // Verify the current password first so a stolen open session cannot silently change it.
    const check = await supabase.auth.signInWithPassword({ email: user.email, password: current });
    if (check.error) {
      setBusy(false);
      setErrs({ current: 'Current password is incorrect.' });
      return;
    }
    const { error } = await supabase.auth.updateUser({ password: next });
    setBusy(false);
    if (error) { setFormError(authMessage(error)); return; }
    form.reset();
    setOk('Password changed.');
  }

  return (
    <form className="form-section" onSubmit={onSubmit} noValidate>
      <h2>Password</h2>
      <Notice kind="bad">{formError}</Notice>
      <Notice kind="ok">{ok}</Notice>
      <Field id="st-current" label="Current password" error={errs.current}>
        <input id="st-current" name="current" type="password" autoComplete="current-password" aria-invalid={bad('current')} aria-describedby="st-current-err" />
      </Field>
      <Field id="st-next" label="New password" error={errs.next} hint="At least 8 characters.">
        <input id="st-next" name="next" type="password" autoComplete="new-password" aria-invalid={bad('next')} aria-describedby="st-next-hint st-next-err" />
      </Field>
      <Field id="st-confirm" label="Confirm new password" error={errs.confirm}>
        <input id="st-confirm" name="confirm" type="password" autoComplete="new-password" aria-invalid={bad('confirm')} aria-describedby="st-confirm-err" />
      </Field>
      <div><button type="submit" className="btn primary" disabled={busy}>{busy ? 'Updating…' : 'Change password'}</button></div>
    </form>
  );
}

export default function Settings() {
  const signOut = useSignOut();
  return (
    <>
      <PageHead title="Settings" sub="Manage your profile and account details" />
      <section className="card"><NameForm /><EmailForm /><PasswordForm /></section>
      <section className="card">
        <div className="form-section">
          <h2>Log out</h2>
          <p className="hint">End your session on this device.</p>
          <div><button type="button" className="btn" onClick={signOut}>Log out</button></div>
        </div>
      </section>
    </>
  );
}
