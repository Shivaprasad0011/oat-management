import { useEffect, useRef } from 'react';
import { STATUS_CLASS, STATUS_LABEL } from '../lib/format.js';

const PATHS = {
  dashboard: 'M3 3h7v9H3zM14 3h7v5h-7zM14 12h7v9h-7zM3 16h7v5H3z',
  products: 'M21 8l-9-5-9 5 9 5 9-5zM3 8v8l9 5 9-5V8M12 13v8',
  orders: 'M7 4h10a2 2 0 0 1 2 2v14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6a2 2 0 0 1 2-2zM9 11h6M9 15h4',
  sales: 'M3 17l6-6 4 4 8-8M15 7h6v6',
  settings: 'M4 7h9M17 7h3M4 17h3M11 17h9M15 5a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM9 15a2 2 0 1 0 0 4 2 2 0 0 0 0-4z',
  plus: 'M12 5v14M5 12h14',
  edit: 'M4 20h4L19 9l-4-4L4 16v4zM13.5 6.5l4 4',
  trash: 'M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3',
  close: 'M6 6l12 12M18 6L6 18',
  star: 'M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9L12 3z',
  logout: 'M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 16l-4-4 4-4M6 12h10'
};

export function Icon({ name }) {
  return (
    <svg className="ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path d={PATHS[name]} />
    </svg>
  );
}

export function Logo({ size = 32 }) {
  return (
    <svg className="logo" width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
      <rect className="logo-bg" width="32" height="32" rx="9" />
      <path className="logo-stem" d="M16 25V12" fill="none" />
      <g className="logo-fg">
        <ellipse cx="12.2" cy="14" rx="2.2" ry="3.6" transform="rotate(-32 12.2 14)" />
        <ellipse cx="19.8" cy="14" rx="2.2" ry="3.6" transform="rotate(32 19.8 14)" />
        <ellipse cx="12.6" cy="20" rx="2.1" ry="3.3" transform="rotate(-32 12.6 20)" />
        <ellipse cx="19.4" cy="20" rx="2.1" ry="3.3" transform="rotate(32 19.4 20)" />
        <ellipse cx="16" cy="9" rx="2" ry="3.2" />
      </g>
    </svg>
  );
}

export function Pill({ cls, children }) {
  return <span className={'pill ' + cls}>{children}</span>;
}

export function OrderPill({ status }) {
  return <Pill cls={STATUS_CLASS[status]}>{STATUS_LABEL[status]}</Pill>;
}

export function Spinner({ label = 'Loading' }) {
  return (
    <div className="loading" role="status" aria-live="polite">
      <span className="spinner" aria-hidden="true" />
      <span>{label}…</span>
    </div>
  );
}

export function ErrorBanner({ children, onRetry }) {
  if (!children) return null;
  return (
    <div className="banner bad" role="alert">
      <span>{children}</span>
      {onRetry ? <button type="button" className="btn sm" onClick={onRetry}>Try again</button> : null}
    </div>
  );
}

export function Field({ id, label, error, hint, children }) {
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      {children}
      {hint ? <small className="hint" id={id + '-hint'}>{hint}</small> : null}
      <small className="err" id={id + '-err'} role={error ? 'alert' : undefined}>{error || ''}</small>
    </div>
  );
}

export function Kpi({ label, icon, value, sub, text }) {
  return (
    <div className="kpi">
      <div className="kpi-top">
        <span className="kpi-label">{label}</span>
        <span className="kpi-chip"><Icon name={icon} /></span>
      </div>
      <div className={'kpi-value' + (text ? ' text' : '')}>{value}</div>
      <div className="kpi-sub">{sub}</div>
    </div>
  );
}

export function PageHead({ title, sub, actions }) {
  return (
    <header className="page-head">
      <div>
        <h1>{title}</h1>
        <p>{sub}</p>
      </div>
      {actions ? <div className="page-actions">{actions}</div> : null}
    </header>
  );
}

export function Empty({ title, children, action }) {
  return (
    <div className="empty">
      <strong>{title}</strong>
      <span>{children}</span>
      {action}
    </div>
  );
}

// Dialog with Escape to close, a focus trap, and focus returned to the opener.
export function Modal({ title, onClose, children, footer }) {
  const ref = useRef(null);
  const opener = useRef(document.activeElement);

  useEffect(() => {
    const node = ref.current;
    const first = node.querySelector('[data-autofocus]') || node.querySelector('input,select,button');
    if (first) first.focus();
    const previous = opener.current;
    function onKey(e) {
      if (e.key === 'Escape') { onClose(); return; }
      if (e.key !== 'Tab') return;
      const items = Array.from(node.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled])'));
      if (!items.length) return;
      const firstEl = items[0];
      const lastEl = items[items.length - 1];
      if (e.shiftKey && document.activeElement === firstEl) { e.preventDefault(); lastEl.focus(); }
      else if (!e.shiftKey && document.activeElement === lastEl) { e.preventDefault(); firstEl.focus(); }
    }
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      if (previous && document.contains(previous)) previous.focus();
    };
  }, [onClose]);

  return (
    <div className="backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title" ref={ref}>
        <div className="modal-head">
          <h2 id="modal-title">{title}</h2>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Close"><Icon name="close" /></button>
        </div>
        {children}
        {footer}
      </div>
    </div>
  );
}
