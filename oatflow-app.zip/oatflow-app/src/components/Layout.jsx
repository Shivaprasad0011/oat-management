import { useRef, useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import { supabase } from '../lib/supabase.js';
import { Icon, Logo, Spinner, ErrorBanner } from './ui.jsx';
import { useData } from '../data.jsx';

const NAV = [
  { to: '/', label: 'Dashboard', icon: 'dashboard', title: 'Sales overview and key metrics', end: true },
  { to: '/products', label: 'Products', icon: 'products', title: 'View and manage oats products' },
  { to: '/orders', label: 'Orders', icon: 'orders', title: 'Create and track orders' },
  { to: '/sales', label: 'Sales', icon: 'sales', title: 'View your sales records' },
  { to: '/settings', label: 'Settings', icon: 'settings', title: 'Manage profile and account details' }
];

export function useSignOut() {
  const navigate = useNavigate();
  return async function signOut() {
    await supabase.auth.signOut();
    navigate('/login', { replace: true });
  };
}

export default function Layout() {
  const { user, displayName } = useAuth();
  const { loading, error, reload } = useData();
  const signOut = useSignOut();
  const [busy, setBusy] = useState(false);
  const [toastText, setToastText] = useState('');
  const [toastOn, setToastOn] = useState(false);
  const timer = useRef(null);

  function toast(msg) {
    setToastText(msg);
    setToastOn(true);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setToastOn(false), 2600);
  }

  async function onSignOut() {
    setBusy(true);
    await signOut();
  }

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="sidebar-inner">
          <div className="brand">
            <Logo />
            <div className="brand-text"><strong>OatFlow</strong><span>Sales manager</span></div>
          </div>
          <nav className="nav" aria-label="Main">
            {NAV.map((n) => (
              <NavLink key={n.to} to={n.to} end={n.end} title={n.title}>
                <Icon name={n.icon} />
                <span className="label">{n.label}</span>
              </NavLink>
            ))}
          </nav>
          <div className="profile">
            <div className="avatar" aria-hidden="true">{(displayName || '?').charAt(0).toUpperCase()}</div>
            <div className="profile-text">
              <strong>{displayName}</strong>
              <span title={user.email}>{user.email}</span>
            </div>
            <button type="button" className="icon-btn" onClick={onSignOut} disabled={busy} aria-label="Log out" title="Log out">
              <Icon name="logout" />
            </button>
          </div>
        </div>
      </aside>
      <main className="main">
        <div className="container">
          <div className="mobile-brand"><Logo size={28} />OatFlow</div>
          <div id="view">
            {loading ? <Spinner label="Loading your data" /> : (
              <>
                <ErrorBanner onRetry={reload}>{error}</ErrorBanner>
                <Outlet context={{ toast }} />
              </>
            )}
          </div>
        </div>
      </main>
      <div className={'toast' + (toastOn ? ' show' : '')} role="status" aria-live="polite">{toastText}</div>
    </div>
  );
}
