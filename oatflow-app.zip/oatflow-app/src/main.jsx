import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx';
import { AuthProvider } from './auth.jsx';
import { isConfigured } from './lib/supabase.js';
import './styles.css';

function MissingConfig() {
  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <h1>OatFlow is not configured</h1>
        <p className="auth-sub">
          Add <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code> to a file named
          <code> .env.local</code>, then restart the app. See <code>.env.example</code>.
        </p>
      </div>
    </div>
  );
}

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    {isConfigured ? (
      <BrowserRouter>
        <AuthProvider>
          <App />
        </AuthProvider>
      </BrowserRouter>
    ) : (
      <MissingConfig />
    )}
  </React.StrictMode>
);
