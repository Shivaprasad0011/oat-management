# OatFlow test plan

Three groups: authentication, account isolation, unauthorized access. Use two accounts, **Alice** and **Bob**
(two different emails). Use a private window for Bob so the sessions do not mix.

## 0. Automated database checks (already run)

`supabase/tests/isolation.sql` simulates Alice, Bob and a signed-out visitor inside the database, using the same
role and JWT claims Supabase sets for API requests. It ends with an intentional error that rolls everything back,
so nothing is saved. Its message lists 33 PASS/FAIL lines.

Result on the `oatflow` project: **33 of 33 checks passed.**

Re-run it after any change to policies, grants or functions (paste the file into the Supabase SQL editor).

## 1. Authentication

| # | Steps | Expected |
|---|-------|----------|
| A1 | Open `/signup`. Submit empty. | Messages under name, email and password. No request is sent. |
| A2 | Sign up with a 5-character password. | "Use at least 8 characters." |
| A3 | Sign up Alice with a valid name, email, password. | Either lands on the dashboard, or shows "Check your email" (when email confirmation is on). |
| A4 | Log in with a wrong password. | "Email or password is incorrect." The message is the same for an unknown email. |
| A5 | Log in as Alice. | Dashboard shows Alice's name and email in the sidebar. |
| A6 | Refresh the page. | Still signed in. Data reloads. |
| A7 | Click Log out. | Back on `/login`. |
| A8 | After logout, press the browser Back button. | Redirected to `/login`. No data is visible. |
| A9 | Signed out, open `/products`, `/orders`, `/sales`, `/settings` directly. | Each redirects to `/login`. |
| A10 | Signed in, open `/login` or `/signup`. | Redirected to the dashboard. |
| A11 | Settings: change the display name. | Success message. Sidebar name updates. Persists after refresh. |
| A12 | Settings: change the email. | Message says to confirm through the emailed link. Email changes only after confirming. |
| A13 | Settings: change password with a wrong current password. | "Current password is incorrect." |
| A14 | Settings: change password correctly, log out, log in with the new one. | Works. The old password no longer works. |

## 2. Account isolation

Set up: as Alice add product "Alice Oats" and create one order. As Bob (private window) add "Bob Oats".

| # | Steps | Expected |
|---|-------|----------|
| I1 | As Bob open Products, Orders, Sales, Dashboard. | Only Bob's rows. No "Alice Oats", no Alice orders. |
| I2 | Compare dashboard totals for both accounts. | Each reflects only its own data. |
| I3 | As Bob, create an order. | Bob's first order is `OF-1001`, independent of Alice's numbering. |
| I4 | Edit and delete a product as Alice. | Bob's list does not change. |
| I5 | Log out Alice and log in as Bob in the same browser. | No trace of Alice's data, even before the new load finishes. |

## 3. Unauthorized access (run against the live API)

Get Alice's product id (from the Supabase table editor), then sign in as Bob and take his access token
(browser dev tools > Application > local storage, key `sb-<project-ref>-auth-token`). Use the project URL and
anon key from `.env.local`.

| # | Request | Expected |
|---|---------|----------|
| U1 | `GET /rest/v1/products` with only the anon key (no user token). | Error 401 or permission denied. No rows. |
| U2 | `GET /rest/v1/products?id=eq.<alice_product_id>` with Bob's token. | `[]` |
| U3 | `PATCH /rest/v1/products?id=eq.<alice_product_id>` with Bob's token, body `{"price":1}`. | Updates 0 rows. Alice's price is unchanged. |
| U4 | `DELETE /rest/v1/products?id=eq.<alice_product_id>` with Bob's token. | Deletes 0 rows. |
| U5 | `POST /rest/v1/products` with Bob's token and `"user_id": "<alice_id>"`. | Rejected (permission denied). |
| U6 | `POST /rest/v1/rpc/create_order` with Bob's token and Alice's product id. | Error "Product not found." |
| U7 | `POST /rest/v1/orders` with Bob's token. | Rejected. Orders can only be created by `create_order`. |
| U8 | `PATCH /rest/v1/orders` with Bob's token on Alice's order, body `{"status":"completed"}`. | Updates 0 rows. |
| U9 | As Alice, `PATCH /rest/v1/orders` with `{"total_price":1}` or `{"unit_price":1}`. | Rejected. Only `status` is editable. |
| U10 | Open the app with a tampered URL, for example `/orders?id=<alice_order_id>`. | No effect. Pages never take ids from the URL. |
| U11 | Search the built JS for `service_role`. | Not present. Only the anon key is shipped. |

## 4. Input validation

| # | Steps | Expected |
|---|-------|----------|
| V1 | Add a product with price 0, negative stock, or an empty name. | Form message. Nothing is saved. |
| V2 | Create an order with quantity above stock. | "Only N packs are in stock." |
| V3 | Create an order, then check the product. | Stock is reduced by the quantity. |
| V4 | Send quantity 0 or status "shipped" straight to `create_order`. | Server error. Validation is also enforced in the database, not only in forms. |

## 5. Interface checks

Check each page at desktop, tablet (about 800 px) and phone (about 390 px) widths: sidebar becomes an icon strip,
then a bottom tab bar, and tables become stacked cards. Check loading, empty and error states, and that
keyboard focus is visible and the dialogs close with Escape.
