# OatFlow

Oats sales management app. React + Vite front end, Supabase for sign-in and the database.

## What it does

Sign up, log in and log out. Dashboard, Products, Orders, Sales and Settings pages. Every product, order and
sales record belongs to one account, and the database refuses access to anyone else's rows.

## How privacy is enforced

Privacy lives in the database (`supabase/migrations/0001_init.sql`), not in the screens.

- `products` and `orders` each have a `user_id` that defaults to the signed-in user.
- Row-Level Security policies allow a user to read and change only rows where `user_id` matches their own id.
- The signed-out (`anon`) role has no access to any table.
- Column grants limit what a client can write: users cannot change `user_id`, order prices or quantities.
- Orders are created only by the `create_order()` function. It validates input, checks stock, lowers stock and
  numbers the order in one step, and only touches the caller's own rows.
- `sales_records` is a view over completed orders that runs with the caller's permissions.
- Passwords are handled by Supabase Auth. The app never stores or sees them after submission.
- The app ships only the public (anon / publishable) key. Never add the `service_role` key.

## Run it

```bash
npm install
cp .env.example .env.local     # already filled in for the "oatflow" project
npm run dev
```

Open http://localhost:5173.

## Database

The migration is already applied to the Supabase project `oatflow` (ref `wzbknsaxwcrhztqxkutr`).
To use another project, run `supabase/migrations/0001_init.sql` in its SQL editor, then put that project's URL and
anon key in `.env.local`.

## Settings to check in the Supabase dashboard

- **Authentication > Providers > Email**: choose whether new users must confirm their email. The app handles both.
- **Authentication > URL Configuration**: add your deployed site URL so confirmation links return to the app.
- **Authentication > Password**: the app requires at least 8 characters. Raise the project minimum to match or exceed it.

## Deploy

`npm run build` creates `dist/`. Host it on any static host. `vercel.json` and `public/_redirects` send every path
to `index.html` so refreshing `/orders` works.

## Tests

See `TEST_PLAN.md`. The database checks are in `supabase/tests/isolation.sql`.

## Structure

```
supabase/migrations/0001_init.sql   tables, policies, grants, create_order(), sales view
supabase/tests/isolation.sql        two-account and signed-out tests
src/auth.jsx                        session handling
src/data.jsx                        loads and changes the signed-in user's data
src/App.jsx                         routes, login redirect
src/pages/                          Login, Signup, Dashboard, Products, Orders, Sales, Settings
src/components/                     Layout (sidebar, profile, toast) and shared UI
src/lib/                            Supabase client and formatting
```
